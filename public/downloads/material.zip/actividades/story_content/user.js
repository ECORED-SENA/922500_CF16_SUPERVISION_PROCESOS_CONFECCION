function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6NICKc5hgkS":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

