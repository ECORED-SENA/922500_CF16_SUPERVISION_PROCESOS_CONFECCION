function ExecuteScript(strId)
{
  switch (strId)
  {
      case "63d3UUslT3c":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

